
class Main
{
    public static void main(String args[])
    {
        // instantiating Singleton class with variable x
        Singleton CAT = Singleton.getInstance();
  
        // instantiating Singleton class with variable y
        Singleton BAT = Singleton.getInstance();
  
        // instantiating Singleton class with variable z
        Singleton MAT = Singleton.getInstance();
  
        // changing variable of instance x
        CAT.s = (CAT.s).toUpperCase();
  
        System.out.println("String from CAT is " + CAT.s);
        System.out.println("String from BAT is " + BAT.s);
        System.out.println("String from MAT is " + MAT.s);
        System.out.println("\n");
  
        // changing variable of instance z
        MAT.s = (MAT.s).toLowerCase();
  
        System.out.println("String from CAT is " + CAT.s);
        System.out.println("String from BAT is " + BAT.s);
        System.out.println("String from MAT is " + MAT.s);
    }
}