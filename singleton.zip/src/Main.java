
class Main
{
    public static void main(String args[])
    {
       
        Singleton CAT = Singleton.getInstance();
  
        
        Singleton BAT = Singleton.getInstance();
  
       
        Singleton MAT = Singleton.getInstance();
  
        
        CAT.s = (CAT.s).toUpperCase();
  
        System.out.println("String from CAT is " + CAT.s);
        System.out.println("String from BAT is " + BAT.s);
        System.out.println("String from MAT is " + MAT.s);
        System.out.println("\n");
  
       
        MAT.s = (MAT.s).toLowerCase();
  
        System.out.println("String from CAT is " + CAT.s);
        System.out.println("String from BAT is " + BAT.s);
        System.out.println("String from MAT is " + MAT.s);
    }
}